const client = require('nekos.life');
const Discord = require('discord.js')
const neko = new client();
const config = require("../../config.json")
module.exports = {
  name: "2dfeet",
  category: "🔞 NSFW Commands",
  usage: "2dfeet",
  run: async (client, message, args) => {
  //command
  
 
      

  //Checks channel for nsfw
  var errMessage = "\`Đây không phải là Kênh NSFW\`";
  if (!message.channel.nsfw) {
      message.react('💢');

      return message.reply(errMessage)
      .then(msg => {
      msg.delete({ timeout: 3000 })
      })
      
  }

        async function work() {
        let owo = (await neko.nsfw.feet());

        const feet = new Discord.MessageEmbed()
        .setTitle("Feet")
        .setImage(owo.url)
        .setColor(config.colors.yes).setFooter(client.user.username, config.AVATARURL)
        .setURL(owo.url);
        message.channel.send(feet);

}

      work();
}
                };
