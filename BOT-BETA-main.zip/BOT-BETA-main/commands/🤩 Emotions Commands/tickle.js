const client = require('nekos.life');
const Discord = require('discord.js')
const neko = new client();
const config = require("../../config.json")

module.exports = {
  name: "tickle",
  category: "🤩 Emotions Commands",
  description: "\`cù một người dùng được đề cập\`",
  usage: "tickle [@User]",
  run: async (client, message, args) => {
 
      let user = message.mentions.users.first();
      if(!user) message.author;
        
        async function work() {
        let owo = (await neko.sfw.poke());

        const tickleembed = new Discord.MessageEmbed()
        .setTitle(user.username + " Bạn đã bị nhột ")
        .setDescription((user.toString() + " bị cù bởi " + message.author.toString()))
        .setImage(owo.url)
        .setColor(config.colors.yes).setFooter(client.user.username, config.AVATARURL)
        .setURL(owo.url);
        message.channel.send(tickleembed);

}

      work();
}
                };
